gsap.registerPlugin(MotionPathPlugin);



gsap.to('.nuage', {
  motionPath: {
    transformOrigin: '0% 0%',
    align: '.cls-1',
    path: '.cls-1',
    start: 1,
    end: 0
  },
  duration: 3,
  repeat: 100,
})
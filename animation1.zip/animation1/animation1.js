gsap.registerPlugin(ScrollTrigger);
gsap.registerPlugin(MotionPathPlugin);

gsap.to('.handshake1', { 
    scrollTrigger: {
        trigger:'.all',
        markers: false,
        start:'bottom center',
        end:'bottom 30%',
        scrub: true,
    },
    x: '-200px',
    y: '-35px',
    opacity: 1,
    rotation: 2,
})

gsap.to('.handshake2', {
    scrollTrigger: {
        trigger:'.hanshake1',
        markers: false,
        start:'bottom center',
        end:'bottom 30%',
        scrub: true,
    },
    rotation: -2,
    x: '200px',
    opacity: 1,
})
